const words = [
    { es: "Hola", en: "Hello" },
    { es: "Mundo", en: "World" },
    { es: "Estudio", en: "Study" },
    { es: "Aprender", en: "Learn" },
    { es: "Idioma", en: "Language" },
    { es: "Amigo", en: "Friend" },
    { es: "Familia", en: "Family" },
    { es: "Trabajo", en: "Work" },
    { es: "Escuela", en: "School" },
    { es: "Libros", en: "Books" },
    { es: "Comida", en: "Food" },
    { es: "Felicidad", en: "Happiness" },
    { es: "Casa", en: "House" },
    { es: "Agua", en: "Water" },
    { es: "Sol", en: "Sun" },
    { es: "Cielo", en: "Sky" },
    { es: "Coche", en: "Car" },
    { es: "Niño", en: "Boy" },
    { es: "Niña", en: "Girl" },
    { es: "Perro", en: "Dog" },
    { es: "Gato", en: "Cat" },
    // Agregar más palabras aquí hasta completar las 1000
    // ...
    { es: "Viaje", en: "Travel" },
    { es: "Pelota", en: "Ball" },
    { es: "Rápido", en: "Fast" },
    { es: "Lento", en: "Slow" },
    { es: "Feliz", en: "Happy" },
    { es: "Triste", en: "Sad" },
    { es: "Grande", en: "Big" },
    { es: "Pequeño", en: "Small" },
    { es: "Fuerte", en: "Strong" },
    { es: "Débil", en: "Weak" },
    { es: "Cielo", en: "Sky" },
    { es: "Mar", en: "Sea" },
    { es: "Montaña", en: "Mountain" },
    { es: "Río", en: "River" },
    { es: "Árbol", en: "Tree" },
    { es: "Flor", en: "Flower" },
    { es: "Playa", en: "Beach" },
    { es: "Viento", en: "Wind" },
    { es: "Nieve", en: "Snow" },
    // Continúa hasta llegar a las 1000 palabras
];

let currentIndex = 0;
let currentSpeed = 6; // Tiempo en segundos para cambiar de palabra
let intervalId = null;
const wordDisplay = document.getElementById('word-display');
const playButton = document.getElementById('play-button');
const speedButton = document.getElementById('speed-button');
const speedInfo = document.getElementById('speed-info');

// Configuración de SpeechSynthesis (Text-to-Speech)
const speechSynthesis = window.speechSynthesis;

// Función para iniciar la reproducción automática de palabras
function startAutoPlay() {
    playButton.disabled = true; // Deshabilitar el botón "Play" mientras se está ejecutando el autoplay
    intervalId = setInterval(() => {
        if (currentIndex < words.length) {
            const word = words[currentIndex];
            wordDisplay.innerHTML = `${word.es} <br> ${word.en}`; // Mostrar palabra en español e inglés una debajo de la otra
            speakWord(word.en); // Reproducir la palabra en inglés
            currentIndex++;
        } else {
            clearInterval(intervalId); // Detener la reproducción automática cuando se terminen las palabras
            wordDisplay.textContent = "¡Has terminado!";
            playButton.disabled = false; // Volver a habilitar el botón "Play"
        }
    }, currentSpeed * 1000); // Cambiar cada 'currentSpeed' segundos
}

// Función para reproducir la palabra
function speakWord(word) {
    const utterance = new SpeechSynthesisUtterance(word);
    utterance.lang = 'en-US'; // Establecer el idioma en inglés
    speechSynthesis.speak(utterance);
}

// Función para cambiar la velocidad
function changeSpeed() {
    if (currentSpeed > 2) {
        currentSpeed -= 2; // Reducir el tiempo en 2 segundos
        speedInfo.textContent = `Velocidad actual: ${currentSpeed} segundos`;
        if (intervalId !== null) {
            clearInterval(intervalId); // Detener la reproducción actual para reiniciar con nueva velocidad
            startAutoPlay(); // Iniciar nuevamente con la nueva velocidad
        }
    }
}

// Event listeners
playButton.addEventListener('click', startAutoPlay);
speedButton.addEventListener('click', changeSpeed);
